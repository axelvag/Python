

class Combattant:

    def __init__(self, vie, attaque):
        self.vie = vie
        self.attaque = attaque
        self.vivant = True
    		
    def	_perdreVie(self, points):
        self.vie = self.vie - points
        if  self.vie  <=  0:
            self.vivant = False
            self.vie = 0   
    
    def	attaquer(self, adversaire):
        adversaire._perdreVie(self.attaque)
